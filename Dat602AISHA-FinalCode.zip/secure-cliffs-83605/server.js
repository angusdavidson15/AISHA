
var express = require('express');
var app = express();
var assert = require('assert');
//var newData;


// set the port of our application
// process.env.PORT lets the port be set by Heroku
var port = process.env.PORT || 5000;

// set the view engine to ejs
app.set('view engine', 'ejs');

// make express look in the public directory for assets (css/js/img)
app.use(express.static(__dirname + '/'));

// set the home page route
app.get('/', function(req, res) {

    // ejs render automatically looks in the views folder
    res.render('index');
});

app.listen(port, function() {
    console.log('Our app is running on http://localhost:' + port);
});



/*// original attempt to connect to database.
// Retrieve
var MongoClient = require('mongodb').MongoClient;

//database url.
var url = 'mongodb://testuser:testuser1@ds048279.mlab.com:48279/nate_test';
const dbname = 'nate_test';
// Connect to the db
MongoClient.connect(url, function (err, db) {
  if (err) {
    console.log('Unable to connect to the mongoDB server. Error:', err);
  } else {
    console.log('Connection established to', url);
    //col.insert(newData);
    //Close connection
    //db.close();
  }
});
*/
