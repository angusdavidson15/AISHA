//var ecclipseY = 150;
//var value = 0; //storing int for startMenu
//var pageint = 0; //stores int for which page you are on.

//Stores the bools for the page switching.
var startpage = false;
var chooseScreen = false;
var personpage = false;
var placepage = false;
var locateper = false;

var welcomeplaying = true;//stores the bool if play sound is allowed
var displayWidth = 800; // The width of the display
var displayHeight = 400; // The height of the display
var s = 90; // stores the size of the icon
//var x = 100;
//var y = 100
var icon = [];// stores the icons to be loaded.
var LOGOimg; // stores the logo image file.
var newData;

var intro;// this is the variable to store the sound file

// defining the variables that will be used in the locate screen.
//this is to position the people icons on the locate screen.
//I also tried to use it to line the location icon to match that of the person
var i1x = 200;
var i1y = 100;
var i2x = 350;
var i2y = 100;
var i3x = 500;
var i3y = 100;
var i1Selc;//
var i2Selc;//These assign which person has been selected.
var i3Selc;//

//defining the variables for all the buttons and button fuctions.
//stores the button information.
var button_choose;
var button_Locate;
var backbutton;
var button_1;
var oldb1 = 0;
var newb1 = 0;

var button_2;
var oldb2 = 0;
var newb2 = 0;

var button_3;
var oldb3 = 0;
var newb3 = 0;

var button_4;
var oldb4 = 0;
var newb4 = 0;

var button_5;
var oldb5 = 0;
var newb5 = 0;

var button_6;
var oldb6 = 0;
var newb6 = 0;

var button_7;
var oldb7 = 0;
var newb7 = 0;

var button_8;
var oldb8 = 0;
var newb8 = 0;


//var dataReady = false;

function preload() { //pre caches data into specific contaniers this helps minimize loading times.
LOGOimg = createImg('AISHALogo2.png');
LOGOimg.hide();
intro = loadSound('AISHA_Welcome_Short.MP3');
	startpage = true;
	icon[0] = createImg('Person_DAD.jpg');
  icon[1] = createImg('Person_MUM.jpg');
  icon[2] = createImg('Person_Child_Son.jpg');
  icon[3] = createImg('Work_Icon.jpg');
	icon[4] = createImg('Shopping_Icon.jpg');
	icon[5] = createImg('School_Icon.jpg');
	icon[6] = createImg('WalkingTheDog_Icon.jpg');
	icon[7] = createImg('Appointment_Icon.jpg');
	button_choose = createButton('choose');
	button_Locate = createButton('Locate');
	backbutton = createButton('Back');
	button_1 = createButton('Dad');
	button_2 = createButton('Mom');
	button_3 = createButton('Son');
	button_4 = createButton('Work');
	button_5 = createButton('School');
	button_6 = createButton('Shopping');
	button_7 = createButton('Appointment');
	button_8 = createButton('WalkingTheDog');
	button_choose.hide();
	button_Locate.hide();
	backbutton.hide();
	button_1.hide();
	button_2.hide();
	button_3.hide();
	button_4.hide();
	button_5.hide();
	button_6.hide();
	button_7.hide();
	button_8.hide();

	var url = 'https://api.mlab.com/api/1/databases/nate_test/collections/Location?apiKey=V6U3QM6jvQVsKJzqeTMRGIUA78_48Y7P'
	loadJSON(url, drawData);
drawData();

  for(var l = 0; l < icon.length; l++)
  {
    icon[l].hide();
  }
}



function setup() {
    var displayWidth = 800;
    var displayHeight = 400;

		//socket = io();
		//socket.on('ServerToClient', dataTransfer);
		//socket = io.connect('https://secure-cliffs-83605.herokuapp.com:5000');
		//socket.on('ServerToClient', dataTransfer);
}
function drawData(data){
	console.log(data);
 newData = data;
}

function draw() {
// This Was used to store the canvas data incase it was needed later.
  var centerX = createCanvas(800, 400);
  fill(0);// Sets fill colour to black for all items unless defined otherwise.

  if (startpage === true)
  {
    startScreen();
  }

  if (chooseScreen === true)
   {
      MainMenu();

   }

  if (personpage === true)
  {
    secondScreen();
    backbutton.show();
    button_1.show();
    button_2.show();
    button_3.show();
  }

  if(placepage === true)
  {
    backbutton.show();
    button_1.hide();
    button_2.hide();
    button_3.hide();
    button_4.show();
    button_5.show();
    button_6.show();
    button_7.show();
    button_8.show();
    ThirdScreen();
  }
  if (locateper === true)
  {
    locate();
    backbutton.show();
  }
    //rect(25, 25, 50, 50); //This cube was to make sure the pages changed correctly/
}

//Determins the events proformed when mouse is clicked.
function mousePressed()
{
	if (welcomeplaying === true)
	{
		intro.play();// plays audio clip.
		welcomeplaying = false;
		//set the retived data to variables that the code uses in locate.
		oldb1 = newData[0];
		newb1 = newData[0];

		oldb2 = newData[1];
		newb2 = newData[1];

		oldb3 = newData[2];
		newb3 = newData[2];

		oldb4 = newData[3];
		newb4 = newData[3];

		oldb5 = newData[4];
		newb5 = newData[4];

		oldb6 = newData[5];
		newb6 = newData[5];

		oldb7 = newData[6];
		newb7 = newData[6];

		oldb8 = newData[7];
		newb8 = newData[7];
		//used in testing to make sure code worked as indended.

		console.log(oldb1);
		console.log(oldb2);
		console.log(oldb3);
		console.log(oldb4);
		console.log(oldb5);
		console.log(oldb6);
		console.log(oldb7);
		console.log(oldb8);

	}
    startpage = false;
    chooseScreen = true;

}
// All the fuctions for changing the page and Storing data for use in locate.
//----------------------------------------------------------------
function ChoosePage(){
		//dataReady = false;
    chooseScreen = false;
    personpage = true;
  	button_choose.hide();
  	button_Locate.hide();
  }
function locatePage(){
		//dataReady = false; //tried to use with sending data to database but could only retrive data.
		console.log(newData);//debuging event but also displays it working.
    chooseScreen = false;
    locateper = true;

  }
function page1(){
  	newb1.Dad = 1;
    personpage = false;
    placepage = true;
		i1Selc = 1;

  }
function page2(){
  	newb2.Mum = 1;
    personpage = false;
    placepage = true;
		i2Selc = 1;
  }
function page3(){
  	newb3.Son = 1;
    personpage = false;
    placepage = true;
		i3Selc = 1;
  }
function confirm1(){
	if (i1Selc === 1)
	{
		newb4.Work = 1;
	}
	if (i2Selc === 1)
	{
		newb4.Work = 2;
	}
	if (i3Selc === 1)
	{
		newb4.Work = 3;
	}
    chooseScreen = true;
  	placepage = false;
		i1Selc = 0;
		i2Selc = 0;
		i3Selc = 0;

  }
function confirm2(){
	if (i1Selc === 1)
	{
		newb5.School = 1;
	}
	if (i2Selc === 1)
	{
		newb5.School = 2;
	}
	if (i3Selc === 1)
	{
		newb5.School = 3;
	}
    chooseScreen = true;
  	placepage = false;
		i1Selc = 0;
		i2Selc = 0;
		i3Selc = 0;
  }
function confirm3(){
	if (i1Selc === 1)
	{
		newb6.Shopping = 1;
	}
	if (i2Selc === 1)
	{
		newb6.Shopping = 2;
	}
	if (i3Selc === 1)
	{
		newb6.Shopping = 3;
	}
    chooseScreen = true;
  	placepage = false;
		i1Selc = 0;
		i2Selc = 0;
		i3Selc = 0;

  }
function confirm4(){
	if (i1Selc === 1)
	{
		newb7.Appointment = 1;
	}
	if (i2Selc === 1)
	{
		newb7.Appointment = 2;
	}
	if (i3Selc === 1)
	{
		newb7.Appointment = 3;
	}
    chooseScreen = true;
  	placepage = false;
		i1Selc = 0;
		i2Selc = 0;
		i3Selc = 0;
  }
function confirm5(){
	if (i1Selc === 1)
	{
		newb8.WalkingTheDog = 1;
	}
	if (i2Selc === 1)
	{
		newb8.WalkingTheDog = 2;
	}
	if (i3Selc === 1)
	{
		newb8.WalkingTheDog = 3;
	}
    chooseScreen = true;
  	placepage = false;
		i1Selc = 0;
		i2Selc = 0;
		i3Selc = 0;
  }
//-------------------------------------------------------------------------

//Functions for all of the pages. like what they should display.
//-----------------------------------------------------------------------
function startScreen() {
    background(255,255,255);//sets background colour to white.
    textSize(15);//set the main texts size.
    text('Tap or click anywhere to begin', 300, 390); //Text instructions on how to continue.
		text('Headphones or speaker required', 300, 375); //message for PI users or devices without a speaker.
    image(LOGOimg, 80, 55); // dispays the logo at given location.
    textSize(20);

}

function MainMenu(){
  background(255,255,255);
  backbutton.hide();
  button_1.hide();
  button_2.hide();
  button_3.hide();
  button_4.hide();
  button_5.hide();
  button_6.hide();
  button_7.hide();
  button_8.hide();
  	image(LOGOimg, 80, 10); // dispays the logo at given location.
  	fill(0);
    strokeWeight(2);
    stroke(10)
  	button_Locate.show();
  	button_choose.show();
		button_choose.position(250, 300);
		button_choose.mousePressed(ChoosePage);
	  button_Locate.position(450, 300);
 		button_Locate.mousePressed(locatePage);
  	var fps = parseInt(frameRate(), 10);
    textSize(15);
    text('frameRate: ' + fps, 10, 390);

}

function secondScreen() {
    background(255,255,255);
  	button_Locate.hide();
  	button_choose.hide();
  	button_4.hide();
    button_5.hide();
    button_6.hide();
    button_7.hide();
    button_8.hide();
 	  personbuttons();
    textSize(50);
 	  text('Who are you', 250, 50);
    strokeWeight(2); //Stroke weight for all shapes
		image(icon[0], 100, 100,s,s);
  	image(icon[1], 250, 100,s,s);
 		image(icon[2], 400, 100,s,s);

    var centerX = (displayWidth / 2);

  	var fps = parseInt(frameRate(), 10);
    textSize(15);
    text('frameRate: ' + fps, 10, 390);
}

function ThirdScreen() {
  	placesbuttons();
    button_Locate.hide();
  	button_choose.hide();
    background(255,255,255);
    textSize(50);
    text('where are you going', 180, 50);
    fill(0);
    strokeWeight(2);
    stroke(10);
  	image(icon[3], 100, 100,s,s);
  	image(icon[4], 400, 100,s,s);
 		image(icon[5], 250, 100,s,s);
	  image(icon[6], 100, 250,s,s);
 		image(icon[7], 250, 250,s,s);

  //places frame rate in bottom Left corner
  	var fps = parseInt(frameRate(), 10);
    textSize(15);
    text('frameRate: ' + fps, 10, 390);
}

//This is the functions in the locate screen and where the database is used.
//only for retival of data preset.
function locate()
{
  	button_choose.hide();
  	button_Locate.hide();
  	button_1.hide();
    button_2.hide();
    button_3.hide();
  	button_4.hide();
    button_5.hide();
    button_6.hide();
    button_7.hide();
    button_8.hide();
 	  backbutton.position(700, 350);
		backbutton.mousePressed(bbutton);
  background(255,255,255);
    textSize(50);
    text('Person is located', 180, 50);
  	fill(0);
    strokeWeight(2);
    stroke(10);
  if (newb1.Dad === 1)
      {
    			image(icon[0], i1x, i1y,s,s);
      }
  if (newb2.Mum === 1)
      {
    			image(icon[1], i2x, i2y,s,s);
      }
  if (newb3.Son === 1)
      {
    			image(icon[2], i3x, i3y,s,s);
      }
  if (newb4.Work === 1)
      {
    			image(icon[3], i1x, i1y+100,s,s);
      }
	if (newb4.Work === 2)
			{
					image(icon[3], i2x, i2y+100,s,s);
			}
	if (newb4.Work === 3)
	  	{
					image(icon[3], i3x, i3y+100,s,s);
			}
  if (newb5.School === 1)
      {
    			image(icon[5], i1x, i1y+100,s,s);
      }
	if (newb5.School === 2)
			{
					image(icon[5], i2x, i2y+100,s,s);
			}
	if (newb5.School === 3)
      {
				 	image(icon[5], i3x, i3y+100,s,s);
		  }
  if (newb6.Shopping === 1)
      {
    			image(icon[4], i1x, i1y+100,s,s);
      }

			if (newb6.Shopping === 2)
	  	{
					image(icon[4], i2x, i2y+100,s,s);
			}
	if (newb6.Shopping === 3)
			{
					image(icon[4], i3x, i3y+100,s,s);
			}
  if (newb7.Appointment === 1)
      {
    			image(icon[7], i1x, i1y+100,s,s);
      }
	if (newb7.Appointment === 2)
	   {
		    	image(icon[7], i2x, i2y+100,s,s);
		  }
	if (newb7.Appointment === 3)
		 {
				  image(icon[7], i3x, i3y+100,s,s);
	  }
  if (newb8.WalkingTheDog === 1)
      {
    			image(icon[6], i1x, i1y+100,s,s);
      }
	if (newb8.WalkingTheDog === 2)
			{
				  image(icon[6], i2x, i2y+100,s,s);
		  }
   if (newb8.WalkingTheDog === 3)
			{
	   			 image(icon[6], i3x, i3y+100,s,s);
		  }

//places frame rate in bottom Left corner
  var fps = parseInt(frameRate(), 10);
    textSize(15);
    text('frameRate: ' + fps, 10, 390);
}
//----------------------------------------------------------------------------


// functions for the buttons seperated for each page so they can easilly be seen to edit.
//-----------------------------------------------------------------------------
function personbuttons() {
 /* This function set the location for the buttons on the person select
screen and how they react to inputs.
*/
 	  button_1.position(100, 205);
		button_1.mousePressed(page1);


	  button_2.position(250, 205);
 		button_2.mousePressed(page2);

	  button_3.position(400, 205);
		button_3.mousePressed(page3);

		backbutton.position(700, 350);
		backbutton.mousePressed(bbutton);

}

function placesbuttons() {
/* This function set the location for the buttons on the locations
select screen and how they react to inputs.
*/
 	  button_4.position(100, 205);
		button_4.mousePressed(confirm1);


	  button_5.position(250, 205);
 		button_5.mousePressed(confirm2);


	  button_6.position(400, 205);
		button_6.mousePressed(confirm3);

  	button_7.position(250, 355);
		button_7.mousePressed(confirm4);

  	button_8.position(100, 355);
		button_8.mousePressed(confirm5);

	  backbutton.position(700, 350);
		backbutton.mousePressed(bbutton);
}

// function of the back buttons on each page/screen.
function bbutton()	{
  if (placepage === true){
   	placepage = false;
    personpage = true;

  }

  if (personpage === true)
  {
  	 personpage = false;
     chooseScreen = true;
  }

  if (locateper === true)
  	{
			locateper = false;
      startpage = true;
    }
}
//-----------------------------------------------------------------------------
